import React from 'react';
import { useNavigate } from 'react-router-dom';
import './LoginForm.css';


const LoginForm = () => {
    const navigate = useNavigate();
const gotosidebar=()=>{
    navigate('/Sidebar');
}

    return (
        <>
            <div className="container ">
                <div className="row">
                   
                    <div className="col-lg-4 mx-auto justify-content-center loginform_div mt-5">
                        <form >
                            <h4 className='mt-4 formtitle'>Admin Panel</h4>
                            <div className="mb-3 mt-5">
                                <label for="exampleInputEmail1" className="form-label">Email</label><br />
                                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />

                            </div>
                            <div className="mb-3">
                                <label for="exampleInputPassword1" className="form-label">Password</label><br />
                                <input type="password" class="form-control" id="exampleInputPassword1"/>
 
                            </div>
                            <div className='d-grid gap-2'>
                                <button onClick={()=>gotosidebar()} type="submit" className="btn btn-outline-info btn-lg mb-5">Login</button>
                            </div>
                        </form>
                    </div>
                 
                </div>
            </div>
          
        </>
    )
}


export default LoginForm;