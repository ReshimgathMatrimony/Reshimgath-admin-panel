import React from 'react'

const Updateuser = () => {
  return (
    <div>Updateuser</div>
  )
}

export default Updateuser;