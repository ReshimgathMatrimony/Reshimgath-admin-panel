import React from 'react';

const RechargeUser = () => {
  return (
    <div>RechargeUser</div>
  )
}

export default RechargeUser;