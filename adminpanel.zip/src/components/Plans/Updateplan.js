import React from 'react';

const Updateplan = () => {
  return (
    <div>Updateplan</div>
  )
}

export default Updateplan;