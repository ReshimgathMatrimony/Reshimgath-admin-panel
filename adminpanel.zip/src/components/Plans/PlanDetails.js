import React from 'react';
import { Link } from 'react-router-dom';
import deleteImg from '../../components/images/bin.png';
import editImg from '../../components/images/edit.png';


const PlanDetails = () => {
  return (
    <>
      <h4 className='text-center mt-5'>Plan Details</h4>
      <div className='d-grid gap-2 d-md-flex justify-content-md-end '>
        <button className='btn btn-primary me-md-2 mt-3 mb-3 '><Link className='text-white text-decoration-none' to="/createplan">Create New Plan</Link></button>
      </div>
      <table className="table">
        <thead>
          <tr>
            <th scope="col">Sr.No</th>
            <th scope="col">Plan</th>
            <th scope="col">Rs</th>
            <th scope="col">Update</th>
            <th scope="col">Delete</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td>Mark</td>
            <td>@mdo</td>
            <td><img src={editImg} /></td>
            <td><img src={deleteImg} /></td>
          </tr>
        </tbody>
      </table>
    </>
  )
}

export default PlanDetails;