import React from 'react';
import './Createplan.css';
import axios from 'axios';

const Createplan = () => {

 
  const handleSubmit=(e)=>{
    e.preventDefault()
    const formdata = new FormData(e.target);
    const data = Object.fromEntries(formdata.entries());
    console.log(data);

     // Axios
     
      axios.post("",data).then((res)=>{
        console.log(res.data);
      })
      .catch((err)=>{
        console.log(err);
      })
  
  }
  return (
    <>
      <div classNameNameName="container">
        <form className='mt-5 createplan_div p-3' onSubmit={handleSubmit}>
          <h4>Create New Plan</h4>
          <div className="mb-3 mt-3">
            {/* <label for="exampleInputEmail1" className="form-label">Plan Description</label> */}
            <input name='Plan Description' type="text" placeholder='Plan Description' className="form-control"  aria-describedby="emailHelp" />
          </div>
          <div className="mb-3">
            {/* <label for="exampleInputEmail1" className="form-label">Price</label> */}
            <input name='Price' type="text"placeholder='Price' className="form-control"  aria-describedby="emailHelp" aria-label="Amount" />
          </div>
          <div className="mb-3">
            {/* <label for="exampleInputEmail1" className="form-label">Count of Profile Views</label> */}
            <input name='Views' type="number" placeholder='Count of Profile Views' className="form-control"  aria-describedby="emailHelp" />
          </div>
          <div className="mb-3">
            {/* <label for="exampleInputEmail1" className="form-label">Duration</label> */}
            <input name='Duration' type="text" placeholder='Duration ' className="form-control"  aria-describedby="emailHelp" />
          </div>
          <div className="form-check">
            <input name='online' className="form-check-input" type="checkbox" value="online" id="flexCheckChecked" />
            <label className="form-check-label" for="flexCheckChecked">
              Online Service
            </label>
          </div>
          <div className="form-check mb-3">
            <input  name='offline' className="form-check-input" type="checkbox" value="offline" id="flexCheckChecked" />
            <label className="form-check-label" for="flexCheckChecked">
              Offline Service
            </label>
          </div>
          <button type="submit"  className="btn btn-primary">Create Plan</button>
        </form>
      </div>
    </>
  )
}

export default Createplan;