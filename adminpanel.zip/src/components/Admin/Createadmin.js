import React from 'react';
import './Createadmin.css';


const Createadmin = () => {

    const handleSubmit=(e)=>{
        e.preventDefault()
        const formdata = new FormData(e.target);
        const data = Object.fromEntries(formdata.entries());
        console.log(data);
      }

    return (
        <>
            <div classNameName="container">
                <form className='mt-5 createadmin_div p-3' onSubmit={handleSubmit}>
                    <h3>Create New Admin</h3>
                    <div className="mb-3 mt-4">
                        {/* <label for="exampleInputEmail1" className="form-label">Email</label> */}
                        <input name='email' type="email" placeholder='Email' className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"/>
                    </div>
                    <div className="mb-4">
                        {/* <label for="exampleInputPassword1" className="form-label">Password</label> */}
                        <input name='password' type="password" placeholder='Password' className="form-control" id="exampleInputPassword1"/>
                    </div>
                    <button type="submit"  className="btn btn-primary">Create Admin</button>
                </form>
            </div>
        </>
    )
}

export default Createadmin;