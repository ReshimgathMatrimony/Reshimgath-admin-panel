import React,{useEffect,useState} from 'react';
import { Link } from 'react-router-dom';
import deleteImg from '../../components/images/bin.png';
import axios from 'axios';

const AdminDetails = () => {

  const[admin,setAdmin] =useState([]);

  useEffect(()=>{
      axios.get("http://localhost:3031/admincrud/getalladmins")
      .then((res)=>{
        setAdmin(res.data)
        console.log(res.data);
      })
      .catch((err)=>{
        console.log(err);
      })
  },[])

  const deleteUser =(a)=>{
   
    window.alert("Do you really want to delete this User"+a);
    
  }


  return (
    <>
      <h4 className='text-center mt-5'>Active Admins</h4>
      <div className='d-grid gap-2 d-md-flex justify-content-md-end '>
        <button className='btn btn-primary me-md-2 mt-3 mb-3 '><Link className='text-white text-decoration-none' to="/createadmin">Create New Admin</Link></button>
      </div>
      <table className="table">
        <thead>
          <tr>
            <th scope="col">Sr.No</th>
            <th scope="col">Email</th>
            <th scope="col">Delete</th>
          </tr>
        </thead>
        <tbody>
         {
          admin.map((value,id)=>{
            return(
              <tr>
                <td>{id+1}</td>
                <td>{value.email}</td>
                <td><button className='btn border-none' onClick={()=>deleteUser(2)}><img src={deleteImg} /></button></td>
              </tr>
            )
           })
         }
        </tbody>
      </table>
    </>
  )
}

export default AdminDetails;