import React from 'react';
import './Sidebar.css';
import { Link } from 'react-router-dom';


const Sidebar = () => {
  return (
    <>
      <nav className='navbar navbar-expand-lg d-flex flex-column align-item-start' id='sidebar'>
        <div className='navbar-brand text-light mt-5 sidebar_brand '><h3>Admin Panel</h3></div>
        <div className=''>
          <ul className='navbar-nav d-flex flex-column mt-1 w-100'>
            <li className='nav-item w-100'>
              <Link to='/admin' className='nav-link active text-dark pl-4'>Admin Details</Link>
            </li>
            <li className='nav-item w-100'>
              <Link to='/users' className='nav-link text-dark pl-4 mt-4'>Users</Link>
            </li>
            <li className='nav-item w-100'>
              <Link to='/unpaiduser' className='nav-link text-dark pl-4 mt-4'>Unpaid Users</Link>
            </li>
            <li className='nav-item w-100'>
              <Link to='/successstories' className='nav-link text-dark pl-4 mt-4'>Success Stories</Link>
            </li>
            <li className='nav-item w-100'>
              <Link to='/plandetails' className='nav-link text-dark pl-4 mt-4'>Plan Details</Link>
            </li>
            <li className='nav-item w-100'>
              <Link to='/sendemails' className='nav-link text-dark pl-4 mt-4'>Send Emails</Link>
            </li>
            <li className='nav-item w-100'>
              <Link to='/customerqueries' className='nav-link text-dark pl-4 mt-4 mb-5'>Customer Queries</Link>
            </li>
          </ul>
        </div>
      </nav>

    </>
  )
}

export default Sidebar;