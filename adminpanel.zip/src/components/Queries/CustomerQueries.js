import React from 'react';
import { Link } from 'react-router-dom';


const CustomerQueries = () => {
  return (
    <>
      <h4 className='text-center mt-5'>Customer Queries</h4>
      <table className="table">
        <thead>
          <tr>
            <th scope="col">Sr.No</th>
            <th scope="col">User Query</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Contact</th>
            <th scope="col">Time & Date</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td>Mark</td>
            <td>@mdo</td>
            <td>Mark</td>
            <td>@mdo</td>
            <td>Mark</td>
          </tr>
        </tbody>
      </table>
    </>
  )
}

export default CustomerQueries;