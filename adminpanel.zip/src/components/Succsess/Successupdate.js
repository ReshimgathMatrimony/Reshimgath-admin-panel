import React from 'react'

const Successupdate = () => {
  return (
    <>
      <div classNameName="container ">
        <form className='mt-5'>
          <h3>Update Story</h3>
          <div className="mb-3">
            <label for="exampleInputEmail1" className="form-label">Bride</label>
            <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
          </div>
          <div className="mb-3">
            <label for="exampleInputPassword1" className="form-label">Groom</label>
            <input type="password" className="form-control" id="exampleInputPassword1" />
          </div>
          <div>
            <label for="exampleInputPassword1" className="form-label">Image</label>
            <input type="file" className="form-control" id="exampleInputPassword1" />
          </div>
          <div className="mb-3">
            <label for="exampleInputPassword1" className="form-label">Date</label>
            <input type="date" className="form-control" id="exampleInputPassword1" />
          </div>
          <button type="submit" className="btn btn-primary">Update Story</button>
        </form>
      </div>
    </>
  )
}

export default Successupdate;