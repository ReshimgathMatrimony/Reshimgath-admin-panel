import React,{useState,useEffect} from 'react';
import { Link } from 'react-router-dom';
import deleteImg from '../../components/images/bin.png';
import editImg from '../../components/images/edit.png';
import axios from 'axios';

const SuccessStories = () => {

  const imageFormator = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.readAsDataURL(file)
      reader.onloadend = () => {
        resolve(reader.result)
      }
    })
  }

  const[success,setSuccess] =useState([]);
  useEffect(()=>{
      axios.get("http://localhost:3031/admincrud/getstories")
      .then((res)=>{
        setSuccess(res.data)
        console.log(res.data);
      })
      .catch((err)=>{
        console.log(err);
      })
  },[])

  return (
    <>
    <h4 className='text-center mt-5'>Success Stories</h4>
      <div className='d-grid gap-2 d-md-flex justify-content-md-end '>
        <button className='btn btn-primary me-md-2 mt-3 mb-3 '><Link className='text-white text-decoration-none' to="/successcreate">Create New Story</Link></button>
      </div>
      <table className="table">
        <thead>
          <tr>
            <th scope="col">Sr.No</th>
            <th scope="col">Bride & Groom</th>
            <th scope="col">Update</th>
            <th scope="col">Delete</th>
          </tr>
        </thead>
        <tbody>
          {
            success.map((value,id)=>{
              <tr>
                <td></td>
                <td>{value}</td>
                <td><Link to="/successupdate"><img src={editImg} /></Link></td>
            <td><img src={deleteImg} /></td>
              </tr>
            })
          }
          {/* <tr>
            <th scope="row">1</th>
            <td>Mark</td>
            <td><Link to="/successupdate"><img src={editImg} /></Link></td>
            <td><img src={deleteImg} /></td>
            
          </tr> */}
        </tbody>
      </table>
    </>
  )
}

export default SuccessStories;