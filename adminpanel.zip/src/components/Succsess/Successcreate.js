import React from 'react';
import './Successcreate.css';

const Successcreate = () => {

  const imageFormator = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.readAsDataURL(file)
      reader.onloadend = () => {
        resolve(reader.result)
      }
    })
  }

  const handleSubmit=(e)=>{
    e.preventDefault()
    const formdata = new FormData(e.target);
    const data = Object.fromEntries(formdata.entries());
    const payLoad =  imageFormator 
    console.log(data);
  
  }

  return (
   <>
    <div className="container ">
                <form className='mt-5 createsuccess_div p-3' onSubmit={handleSubmit}>
                  <h3>Create New Story</h3>
                    <div className="mb-3 mt-3">
                        {/* <label for="exampleInputEmail1" className="form-label">Bride</label> */}
                        <input name='bride' type="text" placeholder='Bride' className="form-control" id="exampleInputText" aria-describedby="emailHelp"/>
                    </div>
                    <div className="mb-3">
                        {/* <label for="exampleInputPassword1" className="form-label">Groom</label> */}
                        <input name='groom' type="text" placeholder='Groom' className="form-control" id="exampleInputText"/>
                    </div>
                    <div>
                    <label for="myfile" className="form-label">Image</label>
                    <input name='image' type="file" className="form-control" id="exampleInputFile"/>
                    </div>
                    <div className="mb-3">
                        <label for="exampleInputPassword1" className="form-label">Date</label>
                        <input name='date' type="date" className="form-control" id="exampleInputDate"/>
                    </div>
                    <button type="submit" className="btn btn-primary">Create Story</button>
                </form>
            </div>
   </>
  )
}

export default Successcreate;
